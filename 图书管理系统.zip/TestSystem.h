#pragma once
#include <iostream>
#include "TimeProcess.h"
#include "Book.h"
#include "FileProcess.h"
#include "Menu.h"

using namespace std;

void test_system();
void mov_data_from_person_to_user();